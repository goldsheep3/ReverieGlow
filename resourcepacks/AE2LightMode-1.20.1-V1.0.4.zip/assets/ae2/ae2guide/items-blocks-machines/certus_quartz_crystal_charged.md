---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Charged Certus Quartz Crystal
  icon: charged_certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:charged_certus_quartz_crystal
---

# The Charged Certus Quartz Crystal

<ItemImage id="charged_certus_quartz_crystal" scale="4" />

A <ItemLink id="certus_quartz_crystal" /> that has been run through a <ItemLink id="charger" />. Used in the production of
<ItemLink id="fluix_crystal" /> and [budding certus blocks](../items-blocks-machines/budding_certus.md).

## Recipe

<RecipeFor id="charged_certus_quartz_crystal" />
