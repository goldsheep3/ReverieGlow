# Security Policy

## Reporting a Vulnerability

Use this section to tell people how to report a vulnerability.

Please open an issue
