v 2.9 ( i was slacking so its 5/11/24)
  - Fixed the water bug
  - Improved da stars
  - Some more stuff that i forot to to doc

v2.7 - 3/24/24
  - Improved stars
  - Made sapplings move
  - Updated hover
  
v2.5.1 - 3/16/24
  - Fixed overworld lighting
  - Improved skulk
  - Added pulse to end crystals
        
v2.5 - 3/16/24
 - Fixed light source bug
 - Improved Nether ligting
 - Added effets to blocks       
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   - [?] Like Noteblocks getting a little brighter when powered and a pulse affect to cauldrons with lava in them.
 - Made end sky black 

v2.1 - 3/11/24
Minor bug fixes/features
 - Fixed color when you cant see the light source \
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;   - [?] See `./assets/before-fix` And `./asset/after-fix`
 - Improved perfomance a little bit
 - Added small pulsing affect to warden
    


v2 - 3/10/24
 - Improve the end portal
 - Fix the puddels
 - Fixed bugs and improved chains
 - Added hover affects
 - Uploaded to modwrinth
 - Improved leaves movment